﻿
namespace Lightbug.Kinematic2D.Implementation
{

public enum MovementState
{
	Normal ,
	WallSlide ,
	Dash ,
	JetPack
}

public enum PoseState
{
	Normal ,
	Crouch
}

}

