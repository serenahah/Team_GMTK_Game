﻿// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;
// using UnityEditor;
// using Lightbug.StateMachine;

// namespace Lightbug.Kinematic2D.Implementation
// {

// // [ CustomEditor(typeof( CharacterState ) )]
// // public abstract class CharacterStateEditor : SMStateEditor
// // {
// // 	public override void OnInspectorGUI()
// // 	{
// // 		base.OnInspectorGUI();
// // 	}

// // }

// }