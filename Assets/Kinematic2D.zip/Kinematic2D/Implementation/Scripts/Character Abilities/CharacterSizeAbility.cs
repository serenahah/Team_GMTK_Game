﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Lightbug.Kinematic2D.Implementation
{	

// public class CharacterPoseAbility : CharacterAbility
// {

// 	// protected StateMachineController<PoseState> stateMachineController; 

// 	protected override void Awake()
// 	{
// 		base.Awake();
// 	}
// }

}