﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Lightbug.Kinematic2D.Implementation
{	

// public class CharacterMovementAbility : CharacterAbility
// {
// 	protected StateMachineController<MovementState> stateMachineController; 

// 	protected override void Awake()
// 	{
// 		base.Awake();

// 		stateMachineController = characterController2D.MovementController;
// 	}

// }

}
